# Dildogram - Мессенджер реального времени

Мессенджер с поддержкой личных и групповых чатов, статусами сообщений и загрузкой медиа.

## Стек технологий

- **Бэкенд**: Go 1.21 + Gin + GORM + WebSocket
- **Фронтенд**: React 18 + TypeScript + Tailwind CSS + Vite
- **База данных**: PostgreSQL 15
- **Кэш**: Redis (опционально для сессий)

## Структура проекта

```
dildogram/
├── backend/
│   ├── cmd/
│   │   └── server/
│   │       └── main.go
│   ├── internal/
│   │   ├── config/
│   │   │   └── config.go
│   │   ├── models/
│   │   │   ├── user.go
│   │   │   ├── chat.go
│   │   │   ├── message.go
│   │   │   └── membership.go
│   │   ├── handlers/
│   │   │   ├── auth.go
│   │   │   ├── user.go
│   │   │   ├── chat.go
│   │   │   ├── message.go
│   │   │   └── ws_handler.go
│   │   ├── middleware/
│   │   │   ├── auth.go
│   │   │   └── cors.go
│   │   ├── websocket/
│   │   │   ├── hub.go
│   │   │   ├── client.go
│   │   │   └── message.go
│   │   ├── repository/
│   │   │   ├── user_repo.go
│   │   │   ├── chat_repo.go
│   │   │   └── message_repo.go
│   │   └── service/
│   │       ├── auth_service.go
│   │       ├── chat_service.go
│   │       └── message_service.go
│   ├── pkg/
│   │   ├── hasher/
│   │   │   └── password.go
│   │   ├── jwt/
│   │   │   └── token.go
│   │   └── validator/
│   │       └── validator.go
│   ├── migrations/
│   │   └── 000001_init_schema.up.sql
│   │   └── 000001_init_schema.down.sql
│   ├── uploads/
│   ├── go.mod
│   ├── go.sum
│   └── .env
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── auth/
│   │   │   │   ├── LoginForm.tsx
│   │   │   │   └── RegisterForm.tsx
│   │   │   ├── chat/
│   │   │   │   ├── ChatList.tsx
│   │   │   │   ├── ChatWindow.tsx
│   │   │   │   ├── MessageInput.tsx
│   │   │   │   ├── MessageBubble.tsx
│   │   │   │   └── MessageStatus.tsx
│   │   │   ├── layout/
│   │   │   │   ├── Sidebar.tsx
│   │   │   │   └── Header.tsx
│   │   │   └── ui/
│   │   │       ├── Avatar.tsx
│   │   │       ├── Modal.tsx
│   │   │       └── Button.tsx
│   │   ├── hooks/
│   │   │   ├── useWebSocket.ts
│   │   │   ├── useAuth.ts
│   │   │   └── useChat.ts
│   │   ├── context/
│   │   │   ├── AuthContext.tsx
│   │   │   └── ChatContext.tsx
│   │   ├── services/
│   │   │   ├── api.ts
│   │   │   └── websocket.ts
│   │   ├── store/
│   │   │   ├── authStore.ts
│   │   │   └── chatStore.ts
│   │   ├── types/
│   │   │   ├── user.ts
│   │   │   ├── chat.ts
│   │   │   └── message.ts
│   │   ├── utils/
│   │   │   └── formatTime.ts
│   │   ├── App.tsx
│   │   ├── main.tsx
│   │   └── index.css
│   ├── public/
│   ├── index.html
│   ├── package.json
│   ├── tsconfig.json
│   ├── tailwind.config.js
│   └── vite.config.ts
├── docker-compose.yml
├── Dockerfile.backend
├── Dockerfile.frontend
└── .env.example
```

## Быстрый старт

```bash
# Клонирование репозитория
git clone <repository>
cd dildogram

# Запуск через Docker Compose
docker-compose up -d

# Бэкенд будет доступен на http://localhost:8080
# Фронтенд на http://localhost:3000
```

## API Endpoints

### Аутентификация
- `POST /api/v1/auth/register` - Регистрация пользователя
- `POST /api/v1/auth/login` - Вход по паролю
- `POST /api/v1/auth/sms` - Запрос SMS кода (имитация)
- `POST /api/v1/auth/verify-sms` - Вход по SMS коду
- `POST /api/v1/auth/logout` - Выход
- `GET /api/v1/auth/me` - Получение текущего пользователя

### Пользователи
- `GET /api/v1/users/:id` - Профиль пользователя
- `PUT /api/v1/users/me` - Обновление профиля
- `POST /api/v1/users/avatar` - Загрузка аватарки

### Чаты
- `GET /api/v1/chats` - Список чатов
- `POST /api/v1/chats` - Создание чата
- `GET /api/v1/chats/:id` - Информация о чате
- `PUT /api/v1/chats/:id` - Обновление чата
- `DELETE /api/v1/chats/:id` - Удаление чата
- `POST /api/v1/chats/:id/members` - Добавить участника
- `DELETE /api/v1/chats/:id/members/:userId` - Удалить участника

### Сообщения
- `GET /api/v1/chats/:id/messages` - История сообщений
- `POST /api/v1/chats/:id/messages` - Отправка сообщения
- `PUT /api/v1/messages/:id/read` - Отметка о прочтении

### WebSocket
- `WS /ws` - Подключение к WebSocket

## Статусы сообщений

- `pending` - Отправляется
- `sent` - Отправлено (одна галочка)
- `delivered` - Доставлено (две галочки)
- `read` - Прочитано (две синие галочки)

## Лицензия

MIT
